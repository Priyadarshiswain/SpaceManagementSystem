"use strict";

var connection = new signalR.HubConnectionBuilder().withUrl("cHub").build();

//Disable send button until connection is established
//document.getElementById("sendButton").disabled = true;

connection.on("PublishMessage", function (user, message) {
    var msg = message.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    var encodedMsg = user + " says " + msg;
    var li = document.createElement("li");
    li.textContent = encodedMsg;
    document.getElementById("messagesList").appendChild(li);
});

//connection.on("PublishMessage", function (user, message) {
//    var msg = message.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
//    var encodedMsg = user + " says " + msg;
//    var li = document.createElement("li");
//    li.textContent = encodedMsg;
//    document.getElementById("messagesList").appendChild(li);
//});

connection.start().then(function () {
    console.log("sub con start!")
}).catch(function (err) {
    return console.error(err.toString());
});

//document.getElementById("sendButton").addEventListener("click", function (event) {
//    var user = document.getElementById("userInput").value;
//    var message = document.getElementById("messageInput").value;
//    var room = user;
//    connection.invoke("Publish", user, room, message).catch(function (err) {
//        return console.error(err.toString());
//    });
//    event.preventDefault();
//});

document.getElementById("sub1").addEventListener("click", function (event) {
    var room = document.getElementById("userInput").value;
    connection.invoke("Subscribe", room).catch(function (err) {
        return console.error(err.toString());
    });
    event.preventDefault();
});

document.getElementById("unsub1").addEventListener("click", function (event) {
    var room = document.getElementById("userInput").value;
    connection.invoke("UnSubscribe", room).catch(function (err) {
        return console.error(err.toString());
    });
    event.preventDefault();
});