﻿using Microsoft.AspNetCore.Connections;
using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace SpaceManagementSystem.Hubs
{
    public class CHub : Hub
    {
        public async Task SendMessage(string user, string message)
        {
            await Clients.All.SendAsync("ReceiveMessage", user, message);
        }

        public async Task Publish(string user, string roomName, string message)
        {
            await Clients.Group(roomName).SendAsync("PublishMessage", user, message);
        }

        public Task Subscribe(string roomName)
        {
            return Groups.AddToGroupAsync(Context.ConnectionId, roomName);
        }

        public Task UnSubscribe(string roomName)
        {
            return Groups.RemoveFromGroupAsync(Context.ConnectionId, roomName);
        }
    }
}
