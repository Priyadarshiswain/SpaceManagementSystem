﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SpaceMngSystem.Models
{
    public class PublishModel
    {
        public string PublisherId { get; set; }
        public object LocationId { get; set; }
    }
}
