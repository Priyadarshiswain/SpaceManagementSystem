import { Component, OnInit } from '@angular/core';
//import { SmsService } from '../services/sms.service'
import { PublishModel } from '../models/publish-model'
import { HttpClient } from "@angular/common/http";

@Component({
  selector: 'app-subscriber',
  templateUrl: './subscriber.component.html',
  styleUrls: ['./subscriber.component.css']
})
export class SubscriberComponent implements OnInit {

  ngOnInit() {
  }

  messages: string[] = [];
  publishers: any;
  locations: any;

  constructor(
    //private _smsService: SmsService,
    private _publishModel: PublishModel,
    private _httpClient: HttpClient
  ) {
    this.loadPublishers();
    this.loadLocation();
    this.registerUpdate();
  }

  loadPublishers() {
    this._httpClient.get("assets/publisher.json").subscribe(data => {
      this.publishers = data;
    })
  }


  loadLocation() {
    this._httpClient.get("assets/location.json").subscribe(data => {
      this.locations = data;
    })
  }

  filterLocations(id: number) {
    return this.locations.filter(c => c.pubId == id);
  }

  //publish(): void {
  //  this._publishModel = { PublisherId: "P1", LocationId: "L1" };
  //  this._smsService.PublishData(this._publishModel);
  //}

  //subscribe() {
  //  this._smsService.Subscribe("P1");
  //}

  private registerUpdate(): void {
    //this._smsService.dataReceived.subscribe((data: string) => {
    //  this.messages.push(data);
    //});
  } 

}
