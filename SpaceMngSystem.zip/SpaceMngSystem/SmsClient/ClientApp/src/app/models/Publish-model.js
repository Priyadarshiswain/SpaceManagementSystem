"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublishModel = void 0;
var PublishModel = /** @class */ (function () {
    function PublishModel() {
    }
    return PublishModel;
}());
exports.PublishModel = PublishModel;
//# sourceMappingURL=Publish-model.js.map