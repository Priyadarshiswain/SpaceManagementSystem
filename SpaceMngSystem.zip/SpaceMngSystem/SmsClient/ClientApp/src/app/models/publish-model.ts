export class PublishModel {
  PublisherId: string;
  LocationId: string;
}
